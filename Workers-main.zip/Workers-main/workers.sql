-- your code goes here
CREATE TABLE workers (
id INTEGER,
age_as_of_2025 INTEGER,
name VARCHAR(30)
);
INSERT INTO workers (id, age_as_of_2025, name)
VALUES (1, 12, "Rowdy Piper");

INSERT INTO workers (id, age_as_of_2025, name)
VALUES (2, 12, "Jess McClesky");
